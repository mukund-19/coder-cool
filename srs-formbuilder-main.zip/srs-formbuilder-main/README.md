```
git clone https://github.com/shahishnujr/srs-formbuilder.git
cd srs-formbuilder
```

```
pip install pdfplumber google-generativeai
```
# config.py
```
GEMINI_API_KEY = "their-own-gemini-api-key"
MODEL = "gemini-2.5-flash"
```
# add the srs pdf in this directory before run

```
python main.py
```
# to run the data insertion code:
command to run in vscode (u should have json in ur directory)

1.npm install pg

2. $env:DATABASE_URL="postgresql://postgres:password@localhost:5432/swcs" 
(use ur own postgres url)

3. node migrate_form_data.js

