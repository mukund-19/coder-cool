import re


def split_into_sections(text):
    """
    Split the SRS text into logical sections by SECTION markers.
    Only processes content before APPENDIX sections.
    Only filters out template placeholder sections from Appendix D.
    """
    # Cut off everything from APPENDIX onwards — real sections are never in appendices
    appendix_match = re.search(r'APPENDIX\s+[A-Z]', text, re.IGNORECASE)
    if appendix_match:
        text = text[:appendix_match.start()]

    pattern = r"(SECTION\s+[\d]+\.[\d]+\s*[—\-].*?)(?=SECTION\s+[\d]+\.[\d]+\s*[—\-]|PAGE\s+\d+\s+[A-Z]{3,}|={5,}|$)"
    sections = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)

    if not sections:
        pattern = r"(PAGE\s+\d+.*?)(?=PAGE\s+\d+|$)"
        sections = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)

    if not sections:
        return [text]

    filtered = []
    for s in sections:
        s = s.strip()

        # Skip if too short
        if len(s) < 200:
            continue

        # Skip ONLY template placeholder sections (Appendix D)
        # Real sections never have <...> placeholders in their content
        if re.search(r'<Section Name>|<Field Name>|<Page Name>', s, re.IGNORECASE):
            continue

        filtered.append(s)

    return filtered