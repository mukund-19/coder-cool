import json
import re
import time
from google import genai
import prompts
from config import GEMINI_API_KEY, MODEL

client = genai.Client(api_key=GEMINI_API_KEY)

def clean_output(text):
    text = text.strip()
    text = re.sub(r"```json\s*", "", text)
    text = re.sub(r"```\s*", "", text)
    # Find outermost JSON object or array
    # Try object first
    start = text.find('{')
    end   = text.rfind('}') + 1
    if start != -1 and end > start:
        return text[start:end]
    # Try array
    start = text.find('[')
    end   = text.rfind(']') + 1
    if start != -1 and end > start:
        return text[start:end]
    return text

def call_llm(prompt, text, context=None, retries=3):
    context_info = f"\n\n### CONTEXT ###\n{json.dumps(context, indent=2)}" if context else ""
    full_prompt  = f"{prompt}\n{context_info}\n\n### SRS TEXT ###\n{text}"

    for attempt in range(retries):
        try:
            response = client.models.generate_content(
                model=MODEL,
                contents=full_prompt,
                config={"response_mime_type": "application/json"}
            )
            raw = clean_output(response.text)
            return json.loads(raw)
        except json.JSONDecodeError as e:
            print(f"  ⚠️  JSON parse error attempt {attempt+1}: {e}")
            if attempt < retries - 1:
                time.sleep(3)
        except Exception as e:
            err = str(e).lower()
            if "quota" in err or "rate" in err or "429" in err or "resource" in err:
                wait = 30 * (attempt + 1)
                print(f"  ⏳  Rate limit — waiting {wait}s ...")
                time.sleep(wait)
            else:
                print(f"  ⚠️  Error attempt {attempt+1}: {e}")
                if attempt < retries - 1:
                    time.sleep(5)
    return {}

def extract_categories(text):
    print("  Extracting categories ...")
    return call_llm(prompts.CATEGORIES_PROMPT, text)

def extract_pages(text):
    print("  Extracting pages ...")
    return call_llm(prompts.PAGES_PROMPT, text)

def extract_page_category_mappings(text, context):
    print("  Extracting page_category_mappings ...")
    return call_llm(prompts.PAGE_CATEGORY_MAPPINGS_PROMPT, text, context=context)

def extract_unified_fields(text, context):
    return call_llm(prompts.UNIFIED_FIELDS_PROMPT, text, context=context)

def extract_options(text, context):
    return call_llm(prompts.OPTIONS_PROMPT, text, context=context)

def extract_addmore(text, context):
    return call_llm(prompts.ADDMORE_PROMPT, text, context=context)

def extract_rules(text, context):
    print("  Extracting form rules ...")
    return call_llm(prompts.FORM_RULES_PROMPT, text, context=context)

def extract_meta(text):
    print("  Extracting meta ...")
    return call_llm(prompts.META_PROMPT, text[:3000])  # only needs start of doc