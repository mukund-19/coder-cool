import json
import re
from pdf_utils      import extract_pdf_text, clean_text
from chunk_utils    import split_into_sections
from llm_extractors import (extract_meta, extract_categories, extract_pages,
                             extract_page_category_mappings,
                             extract_unified_fields, extract_options,
                             extract_addmore, extract_rules)
from schema_builder import build_final_json
from master_mapper  import apply_master_table_ids

PDF_PATH    = "CAF_Full_SRS_v7_with_workflow.pdf"
OUTPUT_PATH = "final_schema.json"


def reindex_unified(data, f_off, bf_off):
    """
    Make $F and $BF refs globally sequential across all sections.
    Uses position order (1st field = offset+1) NOT the AI's ref numbers,
    because the AI may use f_start/bf_start from context and cause double-counting.
    """
    f_list  = data.get("form_fields",    [])
    bf_list = data.get("builder_fields", [])

    # Sort by current ref number to preserve section order
    def ref_num(item, key="ref"):
        m = re.search(r'\d+', item.get(key, "0"))
        return int(m.group()) if m else 0

    f_list  = sorted(f_list,  key=lambda x: ref_num(x))
    bf_list = sorted(bf_list, key=lambda x: ref_num(x))

    # Build old-ref → new-ref maps using position, not AI numbers
    f_map  = {ref_num(f): f_off  + i + 1 for i, f in enumerate(f_list)}
    bf_map = {ref_num(b): bf_off + i + 1 for i, b in enumerate(bf_list)}

    for f in f_list:
        old = ref_num(f)
        f["ref"] = f"$F{f_map[old]}"

    for b in bf_list:
        old_bf = ref_num(b)
        old_f  = ref_num(b, "field_ref")
        b["ref"]       = f"$BF{bf_map[old_bf]}"
        b["field_ref"] = f"$F{f_map.get(old_f, f_off + 1)}"

    return f_list, bf_list


def main():
    # ── Extract text ──────────────────────────────────────────────────────────
    print(f"📄  Reading PDF: {PDF_PATH}")
    text = clean_text(extract_pdf_text(PDF_PATH))
    print(f"   {len(text):,} characters extracted")

    # ── Pass 1: Structure (categories, pages, page_category_mappings) ─────────
    print("\n📋  Pass 1: Extracting structure ...")
    cats  = extract_categories(text)
    pages = extract_pages(text)

    pcm_result = extract_page_category_mappings(text, {
        "categories":   cats.get("categories",    []),
        "page_masters": pages.get("page_masters", [])
    })
    pcm_list = pcm_result.get("page_category_mappings", [])

    print(f"   ✅  {len(cats.get('categories', []))} categories")
    print(f"   ✅  {len(pages.get('page_masters', []))} pages")
    print(f"   ✅  {len(pcm_list)} page_category_mappings")

    # ── Pass 2: Fields section by section ────────────────────────────────────
    sections = split_into_sections(text)
    print(f"\n⚙️   Pass 2: Extracting fields section by section ...")
    print(f"   {len(sections)} sections found")

    all_f, all_bf, all_opt, all_ag, all_ac = [], [], [], [], []
    f_off, bf_off = 0, 0

    for i, section in enumerate(sections, 1):
        preview = section.strip()[:80].replace('\n', ' ')
        print(f"\n   [{i}/{len(sections)}] {preview} ...")

        # Fields
        u_data = extract_unified_fields(section, {
            "cats":  cats,
            "pages": pages,
            "pcm":   pcm_list,
        })
        idx_f, idx_bf = reindex_unified(u_data, f_off, bf_off)
        all_f.extend(idx_f)
        all_bf.extend(idx_bf)
        print(f"      ✅  {len(idx_f)} fields")

        # Options
        opts = extract_options(section, {"builder_fields": idx_bf})
        all_opt.extend(opts.get("field_options", []))

        # Add-more groups and columns — reindex BF refs globally
        # Only call addmore AI if section actually has ADD MORE marker
        # Check in Python first — saves tokens and is more reliable than AI
        import re as _re
        has_addmore = bool(_re.search(r'\[\+\]\s*ADD MORE|\bADD MORE\s*\(Repea', section, _re.IGNORECASE))
        if has_addmore:
            am_data = extract_addmore(section, {"builder_fields": idx_bf})
        else:
            am_data = {"addmore_groups": [], "add_more_columns": []}

        ag_list = (am_data.get("addmore_groups")   or
                   am_data.get("add_more_groups")  or [])
        ac_list = (am_data.get("add_more_columns") or
                   am_data.get("addmore_columns")  or [])

        for ag in ag_list:
            ref = ag.get("trigger_builder_field_ref", "")
            m = re.search(r'\d+', ref)
            if m:
                ag["trigger_builder_field_ref"] = f"$BF{int(m.group()) + bf_off}"
        for ac in ac_list:
            ref = ac.get("builder_field_ref", "")
            m = re.search(r'\d+', ref)
            if m:
                ac["builder_field_ref"] = f"$BF{int(m.group()) + bf_off}"

        all_ag.extend(ag_list)
        all_ac.extend(ac_list)

        f_off  += len(idx_f)
        bf_off += len(idx_bf)

    print(f"\n   Total: {len(all_f)} fields, {len(all_bf)} builder_fields")
    print(f"          {len(all_opt)} options, {len(all_ag)} add_more_groups")

    # ── Pass 3: Form rules ────────────────────────────────────────────────────
    print("\n📐  Pass 3: Extracting form rules ...")
    bf_map = [{"ref": b["ref"], "label": b.get("custom_label", "")} for b in all_bf]
    cat_map = cats.get("categories", [])
    rules_data = extract_rules(text, {
        "all_builder_fields": bf_map,
        "all_categories":     cat_map,
    })
    rules = rules_data.get("form_rules", [])
    print(f"   ✅  {len(rules)} rules")

    # ── Meta ──────────────────────────────────────────────────────────────────
    print("\n🔗  Assembling final JSON ...")
    meta_result = extract_meta(text)
    meta = meta_result.get("meta", {
        "department_id": 1, "service_id": "1.0",
        "form_type_id": 1, "form_name": "Form"
    })
    print(f"   ✅  Meta: {meta}")

    # ── Build and save ────────────────────────────────────────────────────────
    final = build_final_json(
        meta, cats, pages, pcm_list,
        all_f, all_bf, all_opt,
        all_ag, all_ac, rules
    )

    apply_master_table_ids(final)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(final, f, indent=2, ensure_ascii=False)

    print(f"\n✅  Saved: {OUTPUT_PATH}")
    print("\n📊  Summary:")
    for k in ["categories", "form_fields", "page_masters", "page_category_mappings",
              "builder_fields", "field_options", "addmore_groups",
              "add_more_columns", "form_rules"]:
        v = final.get(k)
        print(f"   {k:<28}: {len(v) if v else 0}")


if __name__ == "__main__":
    main()
