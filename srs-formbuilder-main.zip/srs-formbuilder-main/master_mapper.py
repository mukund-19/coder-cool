"""
master_mapper.py
----------------
Post-processing step: fills in `master_table_id` for every field_option
where source_type == "MASTER" and master_table_id is currently null.

Called automatically at the end of main.py after build_final_json().
To add more master tables: append rows to MASTER_TABLES below.
"""

import re


# ── Master table registry ─────────────────────────────────────────────────────
# Format: (id, master_name, master_code, [extra_keyword_aliases])
# Add more rows here as your DB grows beyond id 92.

MASTER_TABLES = [
    (1,  "Country Master",                       "COUNTRY",                ["country"]),
    (2,  "State Master",                          "STATE",                  ["state"]),
    (3,  "District Master",                       "DISTRICT",               ["district"]),
    (4,  "Block Master",                          "BLOCK",                  ["block"]),
    (5,  "Tehsil Master",                         "TEHSIL",                 ["tehsil", "taluk", "sub-district"]),
    (6,  "Village Master",                        "VILLAGE",                ["village"]),
    (7,  "Department Master",                     "DEPARTMENT",             ["department"]),
    (8,  "Issuer Master",                         "ISSUER",                 ["issuer"]),
    (9,  "Document Type Master",                  "DOCUMENT_TYPE",          ["document type"]),
    (10,  "Form Type Master",                      "FORM_TYPE",              ["form type"]),
    (11,  "Organisation Nature Master",            "ORG_NATURE",             ["org nature", "organisation nature", "organization nature"]),
    (12,  "Organisation Nature (Education) Master","ORG_NATURE_EDU",         ["org nature edu", "organisation nature education"]),
    (13,  "Current Landuse Master",                "CURRENT_LANDUSE",        ["current landuse", "land use", "landuse"]),
    (14,  "Labour Factory Type Master",            "LABOUR_FACTORY_TYPE",    ["labour factory type"]),
    (15,  "Labour Factory Sec85 Master",           "LABOUR_SEC85",           ["labour sec85", "labour factory section 85"]),
    (16,  "UJS Division Master",                   "UJS_DIVISION",           ["ujs division"]),
    (17,  "UPCL Supply Category Master",           "UPCL_SUPPLY_CATEGORY",   ["upcl supply category"]),
    (18,  "UPCL Supply Subcategory Master",        "UPCL_SUPPLY_SUBCATEGORY",["upcl supply subcategory"]),
    (19,  "UPCL Voltage Master",                   "UPCL_VOLTAGE",           ["upcl voltage"]),
    (20,  "UPCL Division Master",                  "UPCL_DIVISION",          ["upcl division"]),
    (21,  "UPCL Subdivision Master",               "UPCL_SUBDIVISION",       ["upcl subdivision"]),
    (22,  "NIC Code Master",                       "NIC_CODE",               ["nic code", "nic"]),
    (23,  "HSN Code Master",                       "HSN_CODE",               ["hsn code", "hsn"]),
]

# ── Prefixes to strip from custom_label before keyword matching ───────────────
_STRIP_PREFIXES = [
    "authorized signatory",
    "project location",
    "correspondence",
    "corporate",
    "promoter",
    "project",
]


def _build_keyword_map():
    kmap = {}
    for row in MASTER_TABLES:
        master_id, master_name, master_code, aliases = row
        # From master_code: "NIC_CODE" → "nic code"
        kmap[master_code.lower().replace("_", " ")] = master_id
        kmap[master_code.lower()] = master_id
        # From master_name: strip " Master" suffix
        name_kw = re.sub(r"\s*master\s*$", "", master_name, flags=re.IGNORECASE).strip().lower()
        kmap[name_kw] = master_id
        for alias in aliases:
            kmap[alias.lower()] = master_id
    return kmap


_KEYWORD_MAP = _build_keyword_map()


def _resolve(label: str) -> int | None:
    """Try to match a custom_label string to a master_table_id."""
    normalized = label.strip().lower()
    for prefix in _STRIP_PREFIXES:
        if normalized.startswith(prefix):
            normalized = normalized[len(prefix):].strip()
            break

    # Try full stripped phrase first (most specific)
    if normalized in _KEYWORD_MAP:
        return _KEYWORD_MAP[normalized]

    # Then try individual words — but skip if word is followed by "code"
    # e.g. "country code" or "isd country code" should NOT match country master
    words = normalized.split()
    for i, w in enumerate(words):
        if len(w) > 2 and w in _KEYWORD_MAP:
            if i + 1 < len(words) and words[i + 1] == "code":
                continue
            return _KEYWORD_MAP[w]

    return None


def apply_master_table_ids(schema: dict) -> dict:
    """
    Mutates `schema` in-place: fills master_table_id where possible.
    Returns the same schema dict (for chaining).
    Prints a summary to stdout.
    """
    # Build ref → custom_label map from builder_fields
    bf_label = {
        bf["ref"]: (bf.get("custom_label") or bf.get("ref"))
        for bf in schema.get("builder_fields", [])
    }

    updated  = 0
    warnings = []

    for option in schema.get("field_options", []):
        if option.get("source_type") != "MASTER":
            continue
        if option.get("master_table_id") is not None:
            continue  # already set, don't overwrite

        bf_ref = option["builder_field_ref"]
        label  = bf_label.get(bf_ref, bf_ref)
        mid    = _resolve(label)

        if mid is not None:
            option["master_table_id"] = mid
            updated += 1
        else:
            warnings.append((bf_ref, label))

    # ── Summary ───────────────────────────────────────────────────────────────
    print(f"\n🗂️   Master table mapping: {updated} resolved", end="")
    if warnings:
        print(f", {len(warnings)} unresolved (left as null)")
        print("   ⚠️  Fields needing manual master_table_id:")
        for ref, lbl in warnings:
            print(f"      • {ref} → '{lbl}'")
    else:
        print(" — all resolved ✅")

    return schema