/**
 * migrate_form_data.js
 *
 * Reads final_schema.json and inserts data into all form-builder tables
 * in the correct FK-dependency order.
 *
 * USAGE:
 *   npm install pg          (only needed once)
 *   node migrate_form_data.js
 *
 * ENVIRONMENT (set before running):
 *   DATABASE_URL=postgresql://postgres:password@localhost:5432/swcs
 *   JSON_FILE=./final_schema.json   (optional, defaults to ./final_schema.json)
 *
 * Or edit DB_CONFIG below directly.
 */

const { Client } = require("pg");
const fs = require("fs");
const path = require("path");

// ─── CONFIG ──────────────────────────────────────────────────────────────────

const DB_CONFIG = process.env.DATABASE_URL
  ? { connectionString: process.env.DATABASE_URL }
  : {
      host: "localhost",
      port: 5432,
      database: "swcs",
      user: "postgres",
      password: "password",
    };

const JSON_FILE = process.env.JSON_FILE || path.join(__dirname, "final_schema.json");

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function log(msg) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

function slugify(str) {
  return (str || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

// Safely parse a validation_rule that might be a JSON string or already an object
function parseJson(val) {
  if (val === null || val === undefined) return null;
  if (typeof val === "object") return val;
  try {
    return JSON.parse(val);
  } catch {
    return null;
  }
}

// ─── MAIN ────────────────────────────────────────────────────────────────────

async function main() {
  // 1. Load JSON
  if (!fs.existsSync(JSON_FILE)) {
    console.error(`JSON file not found: ${JSON_FILE}`);
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(JSON_FILE, "utf8"));
  const meta = data.meta; // { department_id, service_id, form_type_id, form_name }

  log(`Loaded JSON. service_id=${meta.service_id}  department_id=${meta.department_id}`);

  // 2. Connect to DB
  const client = new Client(DB_CONFIG);
  await client.connect();
  log("Connected to database.");

  // In-memory ref maps  { "$C1": 5, "$F3": 12, ... }
  const refMap = {
    categories: {},   // $C1 → db id
    fields: {},       // $F1 → db id
    pages: {},        // $P1 → db id
    builderFields: {}, // $BF1 → db id
    addMoreGroups: {}, // $AG1 → db id
  };

  try {
    await client.query("BEGIN");

    // ── STEP 0: Ensure m_departments row exists ──────────────────────────────
    log("STEP 0a: Ensuring m_departments row exists...");
    const deptCheck = await client.query(
      "SELECT id FROM m_departments WHERE id = $1",
      [meta.department_id]
    );
    if (deptCheck.rowCount === 0) {
      await client.query(
        `INSERT INTO m_departments
           (id, name, "uniqueTag", ip, "secretKey", "baseUrl", "publicKey",
            abbreviation, "isActive", "createdAt", "updatedAt")
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW(),NOW())
         ON CONFLICT (id) DO NOTHING`,
        [
          meta.department_id,
          `Department ${meta.department_id}`,  // placeholder name
          `DEPT_${meta.department_id}`,
          "0.0.0.0",
          "secret",
          "http://localhost",
          "pubkey",
          `D${meta.department_id}`,
          true,
        ]
      );
      log(`  Inserted placeholder department id=${meta.department_id}`);
    } else {
      log(`  Department id=${meta.department_id} already exists.`);
    }

    // ── STEP 0b: Ensure m_service row exists ─────────────────────────────────
    log("STEP 0b: Ensuring m_service row exists...");
    const svcCheck = await client.query(
      `SELECT id FROM m_service WHERE service_id = $1`,
      [meta.service_id]
    );
    if (svcCheck.rowCount === 0) {
      await client.query(
        `INSERT INTO m_service
           (service_id, department_id, service_name, "isActive", "createdAt", "updatedAt")
         VALUES ($1, $2, $3, true, NOW(), NOW())`,
        [meta.service_id, meta.department_id, meta.form_name]
      );
      log(`  Inserted placeholder service service_id=${meta.service_id}`);
    } else {
      log(`  Service service_id=${meta.service_id} already exists.`);
    }

    // ── STEP 0c: Ensure m_fb_form_types row exists ───────────────────────────
    log("STEP 0c: Ensuring m_fb_form_types row exists...");
    const ftCheck = await client.query(
      `SELECT id FROM m_fb_form_types WHERE id = $1`,
      [meta.form_type_id]
    );
    if (ftCheck.rowCount === 0) {
      await client.query(
        `INSERT INTO m_fb_form_types (id, name, abbr, "isActive", "createdAt", "updatedAt")
         VALUES ($1, $2, $3, true, NOW(), NOW())`,
        [meta.form_type_id, "CAF", "CAF"]
      );
      log(`  Inserted placeholder form_type id=${meta.form_type_id}`);
    } else {
      log(`  FormType id=${meta.form_type_id} already exists.`);
    }

    // ── STEP 1: m_fb_form_categories ─────────────────────────────────────────
    log("STEP 1: Inserting m_fb_form_categories...");
    const usedCodes = new Set();
    for (const cat of data.categories) {
      // Generate a unique category_code
      let baseCode = slugify(cat.category_name);
      let code = baseCode;
      let suffix = 1;
      while (usedCodes.has(code)) {
        code = `${baseCode}_${suffix++}`;
      }
      usedCodes.add(code);

      const res = await client.query(
        `INSERT INTO m_fb_form_categories
           (category_name, name_in_hindi, name, parent_id, category_code,
            is_active, created, modified, "createdAt", "updatedAt")
         VALUES ($1,$2,$3,$4,$5,$6,NOW(),NOW(),NOW(),NOW())
         RETURNING id`,
        [
          cat.category_name,
          cat.name_in_hindi ?? null,
          cat.category_name,        // nameAlt column
          cat.parent_id ?? 0,
          code,
          cat.is_active ?? true,
        ]
      );
      refMap.categories[cat.ref] = res.rows[0].id;
      log(`  ${cat.ref} "${cat.category_name}" → id=${res.rows[0].id} (code=${code})`);
    }

    // ── STEP 2: m_fb_form_field ───────────────────────────────────────────────
    log("STEP 2: Inserting m_fb_form_field...");
    let fieldSeq = 1;
    for (const f of data.form_fields) {
      const formchkId = `FORMCHK_${String(fieldSeq++).padStart(4, "0")}`;
      const catId = refMap.categories[f.category_ref] ?? null;

      const res = await client.query(
        `INSERT INTO m_fb_form_field
           (formchk_id, parent_id, category_id, name, name_in_hindi,
            is_editable, is_formvar_active, created_date, "createdAt", "updatedAt")
         VALUES ($1,$2,$3,$4,$5,$6,$7,NOW(),NOW(),NOW())
         RETURNING id`,
        [
          formchkId,
          0,
          catId,
          f.name,
          f.name_in_hindi ?? null,
          f.is_editable ?? "Y",
          f.is_active ?? true,
        ]
      );
      refMap.fields[f.ref] = res.rows[0].id;
      log(`  ${f.ref} "${f.name}" → id=${res.rows[0].id}`);
    }

    // ── STEP 3: m_fb_page_master ──────────────────────────────────────────────
    log("STEP 3: Inserting m_fb_page_master...");
    for (const p of data.page_masters) {
      const res = await client.query(
        `INSERT INTO m_fb_page_master
           (service_id, page_name, is_active, name_in_hindi, preference, form_id, created, modified)
         VALUES ($1,$2,$3,$4,$5,$6,NOW(),NOW())
         RETURNING id`,
        [
          meta.service_id,
          p.page_name,
          "Y",
          p.name_in_hindi ?? null,
          p.preference,
          0,  // form_id unknown yet; will update after form_mapping insert (step 9)
        ]
      );
      refMap.pages[p.ref] = res.rows[0].id;
      log(`  ${p.ref} "${p.page_name}" → id=${res.rows[0].id}`);
    }

    // ── STEP 4: m_fb_page_category_mapping ───────────────────────────────────
    log("STEP 4: Inserting m_fb_page_category_mapping...");
    for (const pcm of data.page_category_mappings) {
      const pageId = refMap.pages[pcm.page_ref];
      const catId = refMap.categories[pcm.category_ref];

      if (!pageId || !catId) {
        log(`  WARN: Could not resolve refs for page_ref=${pcm.page_ref} category_ref=${pcm.category_ref}. Skipping.`);
        continue;
      }

      await client.query(
        `INSERT INTO m_fb_page_category_mapping
           (page_id, category_id, preference, help_text, is_active)
         VALUES ($1,$2,$3,$4,$5)`,
        [
          pageId,
          catId,
          pcm.preference,
          pcm.help_text ?? null,
          "Y",
        ]
      );
      log(`  page_id=${pageId} ↔ category_id=${catId} (pref=${pcm.preference})`);
    }

    // ── STEP 5: m_fb_form_builder_fields ─────────────────────────────────────
    log("STEP 5: Inserting m_fb_form_builder_fields...");
    for (const bf of data.builder_fields) {
      const pageId = refMap.pages[bf.page_ref];
      const catId = refMap.categories[bf.category_ref];
      const fieldId = refMap.fields[bf.field_ref];

      if (!fieldId) {
        log(`  WARN: No db id for field_ref=${bf.field_ref}. Skipping ${bf.ref}.`);
        continue;
      }

      const validationRule = parseJson(bf.validation_rule);

      const res = await client.query(
        `INSERT INTO m_fb_form_builder_fields
           (service_id, form_id, page_id, category_id, form_field_id,
            preference, input_type, custom_label, help_text, placeholder,
            grid_span, layout_type, component_props,
            is_required, is_editable, is_readonly, is_active,
            min_length, max_length, pattern, validation_rule,
            created, modified)
         VALUES ($1,$2,$3,$4,$5,
                 $6,$7,$8,$9,$10,
                 $11,$12,$13,
                 $14,$15,$16,$17,
                 $18,$19,$20,$21,
                 NOW(),NOW())
         RETURNING id`,
        [
          meta.service_id,           // $1
          0,                          // $2 form_id (placeholder)
          pageId ?? 0,               // $3
          catId ?? 0,                // $4
          fieldId,                   // $5
          bf.preference,             // $6
          bf.input_type,             // $7
          bf.custom_label ?? null,   // $8
          bf.help_text ?? null,      // $9
          bf.placeholder ?? null,    // $10
          bf.grid_span ?? 12,        // $11
          bf.layout_type ?? null,    // $12
          null,                       // $13 component_props
          bf.is_required ?? "N",     // $14
          bf.is_editable ?? "Y",     // $15
          bf.is_readonly ?? "N",     // $16
          bf.is_active ?? "Y",       // $17
          bf.min_length ?? null,     // $18
          bf.max_length ?? null,     // $19
          bf.pattern ?? null,        // $20
          validationRule
            ? JSON.stringify(validationRule)
            : null,                  // $21
        ]
      );
      refMap.builderFields[bf.ref] = res.rows[0].id;
      log(`  ${bf.ref} (${bf.input_type}) → id=${res.rows[0].id}`);
    }

    // ── STEP 6: m_fb_formfield_options ───────────────────────────────────────
    log("STEP 6: Inserting m_fb_formfield_options...");
    for (const opt of data.field_options) {
      const bfId = refMap.builderFields[opt.builder_field_ref];
      if (!bfId) {
        log(`  WARN: No db id for builder_field_ref=${opt.builder_field_ref}. Skipping.`);
        continue;
      }

      const parentBfId = opt.parent_builder_field_ref
        ? (refMap.builderFields[opt.parent_builder_field_ref] ?? null)
        : null;

      await client.query(
        `INSERT INTO m_fb_formfield_options
           (builder_field_id, source_type, static_options,
            master_table_id, parent_builder_field_id, is_active, created, modified)
         VALUES ($1,$2,$3,$4,$5,$6,NOW(),NOW())`,
        [
          bfId,
          opt.source_type,   // "STATIC" | "MASTER"
          opt.static_options ? JSON.stringify(opt.static_options) : null,
          opt.master_table_id ?? null,
          parentBfId,
          "Y",
        ]
      );
      log(`  options for builder_field_id=${bfId} (${opt.source_type})`);
    }

    // ── STEP 7: m_fb_addmore_groups ──────────────────────────────────────────
    log("STEP 7: Inserting m_fb_addmore_groups...");
    for (const ag of data.add_more_groups) {
      const pageId = refMap.pages[ag.page_ref];
      const catId = refMap.categories[ag.category_ref];
      const triggerBfId = refMap.builderFields[ag.trigger_builder_field_ref];

      if (!triggerBfId) {
        log(`  WARN: No db id for trigger_builder_field_ref=${ag.trigger_builder_field_ref}. Skipping.`);
        continue;
      }

      const res = await client.query(
        `INSERT INTO m_fb_addmore_groups
           (service_id, form_id, page_id, category_id,
            trigger_builder_field_id, label, min_rows, max_rows,
            is_active, created, modified)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW(),NOW())
         RETURNING id`,
        [
          meta.service_id,
          0,
          pageId ?? 0,
          catId ?? 0,
          triggerBfId,
          ag.label ?? null,
          ag.min_rows ?? 1,
          ag.max_rows ?? null,
          "Y",
        ]
      );
      refMap.addMoreGroups[ag.ref] = res.rows[0].id;
      log(`  ${ag.ref} "${ag.label}" → id=${res.rows[0].id}`);
    }

    // ── STEP 8: m_fb_addmore_columns ─────────────────────────────────────────
    log("STEP 8: Inserting m_fb_addmore_columns...");
    for (const col of data.add_more_columns) {
      const groupId = refMap.addMoreGroups[col.group_ref];
      const bfId = refMap.builderFields[col.builder_field_ref];

      if (!groupId || !bfId) {
        log(`  WARN: Cannot resolve group_ref=${col.group_ref} or builder_field_ref=${col.builder_field_ref}. Skipping.`);
        continue;
      }

      await client.query(
        `INSERT INTO m_fb_addmore_columns
           (group_id, builder_field_id, col_order)
         VALUES ($1,$2,$3)`,
        [groupId, bfId, col.col_order]
      );
      log(`  group_id=${groupId} builder_field_id=${bfId} col_order=${col.col_order}`);
    }

    // ── STEP 9: m_fb_form_mapping ─────────────────────────────────────────────
    log("STEP 9: Inserting m_fb_form_mapping...");
    const formCode = `CAF_${meta.service_id.replace(/\./g, "_")}`;
    const fmRes = await client.query(
      `INSERT INTO m_fb_form_mapping
         (department_id, service_id, form_type_id, form_name, form_code,
          form_version, is_active, created, modified)
       VALUES ($1,$2,$3,$4,$5,$6,$7,NOW(),NOW())
       ON CONFLICT (department_id, service_id, form_type_id) DO UPDATE
         SET form_name = EXCLUDED.form_name,
             modified  = NOW()
       RETURNING id`,
      [
        meta.department_id,
        meta.service_id,
        meta.form_type_id,
        meta.form_name,
        formCode,
        "1.0",
        "Y",
      ]
    );
    const formMappingId = fmRes.rows[0].id;
    log(`  m_fb_form_mapping id=${formMappingId} (form_code=${formCode})`);

    // ── STEP 9b: Back-fill form_id = formMappingId ───────────────────────────
    log("STEP 9b: Updating form_id back-references...");

    await client.query(
      `UPDATE m_fb_page_master SET form_id = $1, form_code = $2
       WHERE service_id = $3 AND form_id = 0`,
      [formMappingId, formCode, meta.service_id]
    );

    const builderFieldIds = Object.values(refMap.builderFields);
    if (builderFieldIds.length > 0) {
      await client.query(
        `UPDATE m_fb_form_builder_fields SET form_id = $1
         WHERE service_id = $2 AND form_id = 0
           AND id = ANY($3::int[])`,
        [formMappingId, meta.service_id, builderFieldIds]
      );
    }

    const addMoreGroupIds = Object.values(refMap.addMoreGroups);
    if (addMoreGroupIds.length > 0) {
      await client.query(
        `UPDATE m_fb_addmore_groups SET form_id = $1
         WHERE service_id = $2 AND form_id = 0
           AND id = ANY($3::int[])`,
        [formMappingId, meta.service_id, addMoreGroupIds]
      );
    }

    log("  form_id back-fill complete.");

    // ── STEP 10: m_fb_form_rules ──────────────────────────────────────────────
    log("STEP 10: Inserting m_fb_form_rules...");
    for (const rule of data.form_rules) {
      // Resolve $BF refs inside when_json and then_json to real DB ids
      const resolvedWhen = resolveRefs(rule.when_json, refMap.builderFields);
      const resolvedThen = resolveRefs(rule.then_json, refMap.builderFields);

      await client.query(
        `INSERT INTO m_fb_form_rules
           (service_id, form_id, scope, when_json, then_json, is_active, created, modified)
         VALUES ($1,$2,$3,$4,$5,$6,NOW(),NOW())`,
        [
          meta.service_id,
          formMappingId,
          rule.scope,
          JSON.stringify(resolvedWhen),
          JSON.stringify(resolvedThen),
          "Y",
        ]
      );
    }
    log(`  Inserted ${data.form_rules.length} form rules.`);

    // ── COMMIT ────────────────────────────────────────────────────────────────
    await client.query("COMMIT");
    log("✅  Migration completed successfully!");

    // Print summary
    console.log("\n── SUMMARY ──────────────────────────────────────────────");
    console.log(`  Categories inserted  : ${Object.keys(refMap.categories).length}`);
    console.log(`  Form fields inserted : ${Object.keys(refMap.fields).length}`);
    console.log(`  Pages inserted       : ${Object.keys(refMap.pages).length}`);
    console.log(`  Builder fields       : ${Object.keys(refMap.builderFields).length}`);
    console.log(`  Add-more groups      : ${Object.keys(refMap.addMoreGroups).length}`);
    console.log(`  Form mapping id      : ${formMappingId}`);
    console.log(`  Form rules           : ${data.form_rules.length}`);
    console.log("─────────────────────────────────────────────────────────\n");

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("\n❌  Migration FAILED. All changes rolled back.");
    console.error(err);
    process.exit(1);
  } finally {
    await client.end();
  }
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

/**
 * Walk a JSON object and replace any "$BF..." string values
 * with the actual database id from the refMap.
 */
function resolveRefs(obj, builderFieldMap) {
  if (!obj) return obj;
  if (typeof obj === "string") {
    return builderFieldMap[obj] !== undefined ? builderFieldMap[obj] : obj;
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => resolveRefs(item, builderFieldMap));
  }
  if (typeof obj === "object") {
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      result[k] = resolveRefs(v, builderFieldMap);
    }
    return result;
  }
  return obj;
}

main();
