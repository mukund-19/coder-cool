import pdfplumber
import re
from collections import Counter


def extract_pdf_text(pdf_path):
    """Extract text from each page separately, strip repeating headers/footers."""
    pages_text = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                pages_text.append(page_text)

    if not pages_text:
        return ""

    # Detect repeating header/footer lines across pages
    # A line that appears on most pages (>50%) with only page number variation
    # is a running header/footer and should be removed
    repeating = detect_repeating_lines(pages_text)

    # Remove repeating lines from each page
    cleaned_pages = []
    for page_text in pages_text:
        lines = page_text.split('\n')
        filtered = []
        for line in lines:
            # Normalise the line (remove digits) to match against repeating patterns
            normalised = re.sub(r'\d+', '', line.strip())
            if normalised not in repeating:
                filtered.append(line)
        cleaned_pages.append('\n'.join(filtered))

    return '\n'.join(cleaned_pages)


def detect_repeating_lines(pages_text):
    """
    Find lines that repeat across most pages — these are running headers/footers.
    Normalises digits so 'Page 4' and 'Page 5' are treated as the same pattern.
    Returns a set of normalised line patterns to remove.
    """
    total_pages = len(pages_text)
    if total_pages < 2:
        return set()

    # Count how many pages each normalised line appears on
    line_page_count = Counter()
    for page_text in pages_text:
        seen_on_this_page = set()
        for line in page_text.split('\n'):
            normalised = re.sub(r'\d+', '', line.strip())
            if len(normalised) > 10:  # ignore very short lines
                seen_on_this_page.add(normalised)
        for normalised in seen_on_this_page:
            line_page_count[normalised] += 1

    # A line is a repeating header/footer if it appears on more than 50% of pages
    threshold = max(2, total_pages * 0.5)
    repeating = {line for line, count in line_page_count.items()
                 if count >= threshold}

    return repeating


def clean_text(text):
    # Remove standalone page number references
    text = re.sub(r'\bPage\s+\d+\b', '', text, flags=re.IGNORECASE)
    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text)
    return text.strip()