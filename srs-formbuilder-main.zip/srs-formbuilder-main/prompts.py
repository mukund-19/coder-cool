# ─────────────────────────────────────────────────────────────────────────────
# CATEGORIES PROMPT
# ─────────────────────────────────────────────────────────────────────────────
CATEGORIES_PROMPT = """
You are an expert AI that converts SRS documents into structured JSON for a government form builder.

TASK: Extract all FORM CATEGORIES (sections) from the SRS.
NOTE : count only the those with the word SECTION as categories, they can have multiple fields/questions under them
RULES:
1. Each SECTION in the SRS becomes one category, in the ORDER they appear.
2. Refs must be sequential: $C1, $C2, $C3 ...
3. "action" is always "INSERT_NEW".
4. "name_in_hindi" is always null.
5. "parent_id" is always 0.
6. "is_active" is always true.
7. Do NOT invent categories not in the SRS.

OUTPUT — return ONLY valid JSON, no markdown:
{
  "categories": [
    {
      "ref": "$C1",
      "action": "INSERT_NEW",
      "category_name": "Company Details",
      "name_in_hindi": null,
      "parent_id": 0,
      "is_active": true
    }
  ]
}
"""

# ─────────────────────────────────────────────────────────────────────────────
# PAGES PROMPT
# ─────────────────────────────────────────────────────────────────────────────
PAGES_PROMPT = """
You are an expert AI that converts SRS documents into structured JSON for a government form builder.

TASK: Extract all FORM PAGES from the SRS.
NOTE : count only the those with the word PAGE as pages in the heading 
RULES:
1. Each PAGE in the SRS becomes one page_master entry, in order.
2. Refs must be sequential: $P1, $P2 ...
3. "preference" must match the page number order exactly.
4. "name_in_hindi" is always null.
5. Include ALL pages including Payment, Application Signing, Summary.
6. Page names must be Title Case exactly as they appear in the SRS — NOT uppercase.
   Example: "Company Details", "Project Finance", "Supporting Documents"

OUTPUT — return ONLY valid JSON, no markdown:
{
  "page_masters": [
    {
      "ref": "$P1",
      "page_name": "Company Details",
      "preference": 1,
      "name_in_hindi": null
    }
  ]
}
"""

# ─────────────────────────────────────────────────────────────────────────────
# PAGE CATEGORY MAPPINGS PROMPT
# ─────────────────────────────────────────────────────────────────────────────
PAGE_CATEGORY_MAPPINGS_PROMPT = """
You are an expert AI that converts SRS documents into structured JSON for a government form builder.

TASK: Generate PAGE_CATEGORY_MAPPINGS by reading the SRS text and matching each category (section) to the page it belongs to.

You are given in CONTEXT:
- categories: list of {ref, category_name} — all sections extracted from the SRS
- page_masters: list of {ref, page_name} — all pages extracted from the SRS

INSTRUCTIONS:
1. Read the SRS text carefully.
2. For each category (section), find which PAGE it appears under in the SRS.
3. Match it to the correct page_ref from page_masters.
4. "preference" RESETS TO 1 for each new page (it is per-page, not global).
5. "help_text" is the [i] note line from the SRS for that section, or null if none exists.
6. Use the EXACT $P and $C refs from the context — do not invent new ones.
7. Every category must appear exactly once in the mappings.
8. Pages with no sections (like Payment, Signing, Summary) do not get mappings.

OUTPUT — return ONLY valid JSON, no markdown:
{
  "page_category_mappings": [
    {
      "page_ref": "$P1",
      "category_ref": "$C1",
      "preference": 1,
      "help_text": null
    },
    {
      "page_ref": "$P1",
      "category_ref": "$C2",
      "preference": 2,
      "help_text": "Fields in this section auto-fetch from CIN API"
    },
    {
      "page_ref": "$P2",
      "category_ref": "$C4",
      "preference": 1,
      "help_text": "Authorized Signatory is the person authorized to sign the application"
    }
  ]
}
"""

# ─────────────────────────────────────────────────────────────────────────────
# UNIFIED FIELDS PROMPT (form_fields + builder_fields together per section)
# ─────────────────────────────────────────────────────────────────────────────
UNIFIED_FIELDS_PROMPT = """
You are an expert Form Extraction Engine for a government SRS form builder.
 
TASK: Extract EVERY SINGLE field from this SRS section and produce both form_fields and builder_fields.
(DO NOT MISS ANY FIELD UNDER EACH SECTION)
 
CONTEXT provided contains:
- cats: all categories with refs
- pages: all page_masters with refs
- pcm: page_category_mappings so you know which category belongs to which page
 
CRITICAL RULES:
 
1. COMPLETENESS: If the section has 14 fields, return exactly 14 form_fields and 14 builder_fields. Never skip any field.
 
2. REFS: Always start refs from $F1 and $BF1 within each section.
   Number them sequentially: $F1, $F2, $F3 ... and $BF1, $BF2, $BF3 ...
   The system will reindex them globally after extraction.
 
3. LINKING: builder_field["field_ref"] must match the corresponding form_field["ref"].
 
4. CATEGORY AND PAGE MAPPING:
   - Use "category_ref" from cats context matching the section name.
   - Use "page_ref" from pcm context for the page that contains that category.
 
5. INPUT TYPE INFERENCE:
   - "Radio", "Yes/No" → "radio"
   - "Dropdown", "Select", "Choose" → "select"
   - "Multi-select", "Multiselect", "MULTISELECT" → "multiselect"
   - "Upload", "File" → "file"
   - "Textarea", "Description" → "textarea"
   - "Date" → "date"
   - "Number", "numeric" → "number"
   - "Email" → "email"
   - "Mobile", "Tel", "Phone" → "tel"
   - "Checkbox" → "checkbox"
   - Everything else → "text"
 
6. IS_REQUIRED:
   - "Mandatory" → "Y"
   - "Optional" → "N"
   - "Auto Populated" → "N"
   - "Auto Calculated" → "N"
 
7. IS_READONLY:
   - "Auto Populated" or "Auto Calculated" → "Y", is_editable → "N"
   - Everything else → "N", is_editable → "Y"
 
8. GRID SPAN:
   - Address Line fields and Textarea fields → 12
   - All other fields → 6
 
9. ALL builder_field keys required:
   ref, page_ref, category_ref, field_ref,
   preference (1-based within category, reset to 1 for each new category),
   input_type, is_required ("Y" or "N"), is_active ("Y" or "N"), custom_label, grid_span,
   help_text(value from Tool Tip column of SRS), is_editable ("Y" or "N"), is_readonly ("Y" or "N"),
   max_length (Integer or null), min_length (Integer or null),
   pattern (regex string or null), placeholder (value or null),
   validation_rule (null), layout_type (null)
 
   note : layout_type and validation_rule is always null . placeholder has value in json only if word 'placeholder' with it's value is present. mAKE SURE MIN_LENGTH AND MAX_LENGTH IS AN INTEGER IF IS DECIMAL PUT null
 
10. form_field keys: ref, action ("INSERT_NEW"), name, name_in_hindi (null),
    is_editable ("Y"), is_active (true), category_ref
 
11. HELP_TEXT EXTRACTION:
 
   The SRS field rows follow this EXACT column order when a Tool Tip column exists:
   NUMBER  FIELD_NAME  TOOL_TIP  TYPE  GRID  MANDATORY  VALIDATION/NOTES
 
   The Tool Tip text appears BETWEEN the field name and the type keyword
   (TEXT, SELECT, RADIO, NUMBER, DATE, TEL, EMAIL, CHECKBOX, TEXTAREA, FILE, etc.).
 
   Example from SRS:
   "1 New Or Existing Indicates whether this is a brand-new RADIO 6 Mandatory Default: new..."
   Field name = "New Or Existing"
   Tool Tip   = "Indicates whether this is a brand-new application or an existing offline unit"
   Type       = "RADIO"
 
   RULE: Extract the text BETWEEN the end of the field name and the type keyword.
   That is the Tool Tip — use it directly as help_text.
 
   If there is NO text between field name and type keyword, extract from Validation/Notes:
   STEP 1: If empty → null.
   STEP 2: If field is radio/select/multiselect AND notes is a pipe-separated option list → null.
   STEP 3: If notes contains "Max:", "Pattern:", "Validation:", "Source:", "Read-only"
           → take text AFTER THE LAST "|" pipe. If that still contains metadata → null.
   STEP 4: If notes has no metadata keywords → use full notes as help_text.
   STEP 5: Normalize whitespace, strip trailing " .,-". If empty → null.
 
12. OPTION DELIMITER: Options are ONLY separated by "|". A line break is NOT a new option.
    If two words appear on consecutive lines with no "|" between them, they are ONE option
    that wrapped due to PDF width — join them with a space.
 
OUTPUT — return ONLY valid JSON: (follow this exact key order)
{
  "form_fields": [
    {
      "ref": "$F1",
      "action": "INSERT_NEW",
      "name": "New Or Existing Offline",
      "name_in_hindi": null,
      "is_editable": "Y",
      "is_active": true,
      "category_ref": "$C1"
    }
  ],
  "builder_fields": [
    {
      "ref": "$BF1",
      "page_ref": "$P1",
      "category_ref": "$C1",
      "field_ref": "$F1",
      "preference": 1,
      "input_type": "radio",
      "is_required": "Y",
      "is_active": "Y",
      "custom_label": "New Or Existing Offline",
      "grid_span": 6,
      "help_text": null,
      "is_editable": "Y",
      "is_readonly": "N",
      "max_length": null,
      "min_length": null,
      "pattern": null,
      "placeholder": null,
      "validation_rule": null,
      "layout_type": null
    }
  ]
}
"""
 
# ─────────────────────────────────────────────────────────────────────────────
# OPTIONS PROMPT
# ─────────────────────────────────────────────────────────────────────────────
OPTIONS_PROMPT = """
You are an expert AI extracting field options from an SRS document section.

TASK: Extract FIELD OPTIONS for all select, radio, multiselect, and checkbox fields in this section.

CONTEXT contains builder_fields for this section with their refs and labels.

RULES:
1. Only produce options for fields with input_type: select, radio, multiselect, checkbox.
2. source_type is always "STATIC" for inline options, "MASTER" for database-driven options.
3. For MASTER source: static_options must be null, master_table_id is null.
4. For STATIC source: list all options with label (display text) and value (snake_case).
5. Snake_case values: lowercase, spaces replaced with underscore.
6. master_table_id is always null.
7. parent_builder_field_ref is null unless explicit dependency.
8. Match builder_field_ref exactly to the $BF refs from context.
9. OPTION DELIMITER RULE — CRITICAL:
   - Options are ONLY separated by the pipe character "|".
   - A line break or newline does NOT mean a new option.
   - If two words appear on consecutive lines with NO "|" between them, they are
     a SINGLE option that wrapped due to PDF line width — join them with a space.
   - Example: "Uttarkashi\nAjmer" (no pipe) → ONE option: "Uttarkashi Ajmer"
   - Example: "Uttarkashi | Ajmer" (with pipe) → TWO options: "Uttarkashi", "Ajmer"
   - Always treat "|" as the only valid option separator.

OUTPUT — return ONLY valid JSON: (follow this exact key order)
{
  "field_options": [
    {
      "builder_field_ref": "$BF2",
      "source_type": "STATIC",
      "static_options": [
        {"label": "New", "value": "new"},
        {"label": "Existing Offline", "value": "existing_offline"}
      ],
      "master_table_id": null,
      "parent_builder_field_ref": null
    },
    {
      "builder_field_ref": "$BF3",
      "source_type": "MASTER",
      "static_options": null,
      "master_table_id": null,
      "parent_builder_field_ref": null
    }
  ]
}
"""

# ─────────────────────────────────────────────────────────────────────────────
# ADDMORE PROMPT  (addmore_groups + add_more_columns)
# ─────────────────────────────────────────────────────────────────────────────
ADDMORE_PROMPT = """
You are an expert AI detecting repeatable field groups in an SRS document.
 
TASK: Detect ADD MORE / repeatable sections and extract addmore_groups and add_more_columns.
(only when you detect word REPEATABLE/repeatable after [i])
CONTEXT contains builder_fields for this section.
 
RULES:
1. ONLY produce output if the SRS section header line explicitly contains "[+] ADD MORE"
   or "ADD MORE (Repeatable)" text — this appears directly on the SECTION heading line.
   Example of a valid trigger:
   "SECTION 2.2 - Promoter Details   [+] ADD MORE (Repeatable): min 1 / max 10 rows"
   
   Do NOT trigger just because the word "REPEATABLE" appears in the [i] note below
   the heading — that is only a description, not a trigger.
   Do NOT trigger on any other section that does not have "[+] ADD MORE" on its header.
 
2. addmore_groups: one entry per repeatable section.
   - ref: $AG1, $AG2 ...
   - page_ref: page reference from context (e.g. $P2)
   - category_ref: from context
   - trigger_builder_field_ref: $BF ref of the FIRST field in the repeatable section
   - label: section name string
   - min_rows: from SRS (default 1)
   NOTE: do NOT include is_active or max_rows.
 
3. add_more_columns: one entry per field in the repeatable section.
   - group_ref: matches the addmore_group ref
   - builder_field_ref: from context $BF refs
   - col_order: sequential from 1
 
OUTPUT — return ONLY valid JSON: (follow this exact key order)
{
  "addmore_groups": [
    {
      "ref": "$AG1",
      "page_ref": "$P2",
      "category_ref": "$C5",
      "trigger_builder_field_ref": "$BF57",
      "label": "Promoter Details",
      "min_rows": 1
    }
  ],
  "add_more_columns": [
    {"group_ref": "$AG1", "builder_field_ref": "$BF57", "col_order": 1},
    {"group_ref": "$AG1", "builder_field_ref": "$BF58", "col_order": 2}
  ]
}
 
If no "[+] ADD MORE" marker exists in this section header, return:
{"addmore_groups": [], "add_more_columns": []}
"""

# ─────────────────────────────────────────────────────────────────────────────
# FORM RULES PROMPT
# ─────────────────────────────────────────────────────────────────────────────
FORM_RULES_PROMPT = """
You are an expert AI extracting conditional visibility rules from an SRS document.

TASK: Extract ALL CONDITIONAL RULES from the SRS and produce form_rules entries.

CONTEXT contains:
- all_builder_fields: list of {ref, label} for every field in the form.
- all_categories: list of {ref, category_name} for every category.
Use these to resolve field/category names to their exact $BF or $C refs.

RULES:
1. Every "Show X when Y = Z" statement in the SRS becomes one form_rule.
2. "scope" is always "field".
3. when_json contains: field_ref ($BF of the trigger field), operator, value.
4. then_json contains: action ("show"), target_refs (list of $BF refs to show).
   If the rule targets an entire section/category, use the $C ref instead.
   Example: Show entire Correspondence Address section → target_refs: ["$C3"]
5. Operators:
   - Single value → "equals"
   - Multiple values (OR) → "in", value is a comma-separated STRING (NOT an array)
     Example: "expansion,diversification,modernization"
   - Numeric (> 0) → "greater_than", value is "0"
   - Unchecked/false → "equals", value is "false"
6. IMPORTANT: "value" is ALWAYS a plain string, never a JSON array.
7. Values must be snake_case strings.
8. Resolve ALL field/category names to exact refs using the context provided.

OUTPUT — return ONLY valid JSON: (follow this exact key order)
{
  "form_rules": [
    {
      "scope": "field",
      "when_json": {
        "field_ref": "$BF2",
        "operator": "in",
        "value": "expansion,diversification,modernization"
      },
      "then_json": {
        "action": "show",
        "target_refs": ["$BF3"]
      }
    },
    {
      "scope": "field",
      "when_json": {
        "field_ref": "$BF28",
        "operator": "equals",
        "value": "false"
      },
      "then_json": {
        "action": "show",
        "target_refs": ["$C3"]
      }
    }
  ]
}
"""

# ─────────────────────────────────────────────────────────────────────────────
# META PROMPT
# ─────────────────────────────────────────────────────────────────────────────
META_PROMPT = """
You are an expert AI that converts SRS documents into structured JSON for a government form builder.

TASK: Extract the FORM METADATA from the beginning of the SRS document under heading General Details.Just the value is enough

RULES:
1. "department_id" is an integer found next to "Department ID" in the SRS.
2. "service_id" is a string found next to "Service ID" in the SRS.
3. "form_type_id" is an integer found next to "Form Type ID" in the SRS.
4. "form_name" is the full form name found next to "Form Name" in the SRS.
5. If any value is not found, use these defaults: department_id=1, service_id="1.0",
   form_type_id=1, form_name="Form".

EXACT OUTPUT SCHEMA:
{
  "meta": {
    "department_id": 1,
    "service_id": "591.0",
    "form_type_id": 1,
    "form_name": "Combined Application Form (CAF)"
  }
}

Return ONLY valid JSON, no markdown fences.
"""