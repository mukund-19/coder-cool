def build_final_json(meta, categories, pages, page_category_mappings,
                     fields, builder_fields, options, add_more_groups,
                     add_more_columns, rules):
    """
    Assembles the final FormBuilder JSON from all extracted parts.
    page_category_mappings is now passed in directly (extracted by AI).
    """
    return {
        "meta":                    meta,
        "categories":              categories.get("categories", []),
        "form_fields":             fields,
        "page_masters":            pages.get("page_masters", []),
        "page_category_mappings":  page_category_mappings,
        "builder_fields":          builder_fields,
        "field_options":           options,
        "add_more_groups":         add_more_groups if add_more_groups else None,
        "add_more_columns":        add_more_columns if add_more_columns else None,
        "form_rules":              rules
    }